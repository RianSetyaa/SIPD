<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
session_destroy();
header('Location: ' . BASE_URL . 'login.php');
exit;
